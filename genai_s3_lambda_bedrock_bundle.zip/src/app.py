import os, json, gzip
import boto3

s3 = boto3.client("s3")
translate = boto3.client("translate")
bedrock = boto3.client("bedrock-runtime")

OUTPUT_BUCKET = os.environ["OUTPUT_BUCKET"]
SUMMARY_PREFIX = os.environ.get("SUMMARY_PREFIX", "summaries/")
TRANSLATION_PREFIX = os.environ.get("TRANSLATION_PREFIX", "translations/")
TARGET_LANG = os.environ.get("TARGET_LANG", "fr")
MODEL_ID = os.environ.get("MODEL_ID", "anthropic.claude-3-haiku-20240307-v1:0")
MAX_BYTES = int(os.environ.get("MAX_BYTES", "500000"))

def _read_s3_text(bucket, key, max_bytes=MAX_BYTES) -> str:
    obj = s3.get_object(Bucket=bucket, Key=key)
    body = obj["Body"].read(max_bytes + 1)
    if len(body) > max_bytes:
        raise ValueError(f"Object too large (> {max_bytes} bytes).")
    try:
        return body.decode("utf-8")
    except UnicodeDecodeError:
        try:
            return gzip.decompress(body).decode("utf-8")
        except Exception:
            return body.decode("latin-1", errors="ignore")

def _summarize_with_bedrock(text: str) -> str:
    prompt = f"""You are a concise technical summarizer.
Summarize the following text in 5–8 bullet points, preserving key facts:

{text[:20000]}"""
    body = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 800,
        "temperature": 0.2,
        "messages": [{"role":"user","content":[{"type":"text","text":prompt}]}]
    }
    resp = bedrock.invoke_model(
        modelId=MODEL_ID,
        body=json.dumps(body),
        accept="application/json",
        contentType="application/json"
    )
    payload = json.loads(resp["body"].read())
    parts = [blk["text"] for blk in payload.get("output", {}).get("content", []) if blk.get("type")=="text"]
    return "".join(parts).strip()

def _translate(text: str, target_lang: str) -> str:
    out = translate.translate_text(Text=text, SourceLanguageCode="auto", TargetLanguageCode=target_lang)
    return out["TranslatedText"]

def _put_text(bucket: str, key: str, text: str):
    s3.put_object(Bucket=bucket, Key=key, Body=text.encode("utf-8"), ContentType="text/plain; charset=utf-8")

def lambda_handler(event, context):
    rec = event["Records"][0]
    in_bucket = rec["s3"]["bucket"]["name"]
    in_key = rec["s3"]["object"]["key"]

    base_name = in_key.split("/")[-1].rsplit(".", 1)[0]
    summary_key = f"{SUMMARY_PREFIX}{base_name}.summary.txt"
    translation_key = f"{TRANSLATION_PREFIX}{base_name}.summary.{TARGET_LANG}.txt"

    try:
        text = _read_s3_text(in_bucket, in_key)
        summary = _summarize_with_bedrock(text)
        _put_text(OUTPUT_BUCKET, summary_key, summary)

        translated = _translate(summary, TARGET_LANG)
        _put_text(OUTPUT_BUCKET, translation_key, translated)

        return {"status": "ok", "summary_key": summary_key, "translation_key": translation_key}
    except Exception as e:
        err_key = f"errors/{base_name}.error.json"
        _put_text(OUTPUT_BUCKET, err_key, json.dumps({"input_key": in_key, "error": str(e)}, indent=2))
        raise
